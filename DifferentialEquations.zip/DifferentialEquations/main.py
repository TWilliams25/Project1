# Necessary imports
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt


# Equation to calculate CPU time
def cpu_time(i, cpi, t):
    timing = i * cpi * t
    return timing

# Number of instructions in the program
R = float(input('# of Instructions [I]: '))

# The number of cycles per instructions in the program
cyc = float(input('Average Cycles Per Instruction [CPI]: '))

# The average minimum & maximum Clock Cycle time represented in an array
timemin = float(input('Average Minimum Clock Cycle Time [Tmin]: '))
timemax = float(input('Average Maximum Clock Cycle Time [Tmax]: '))

# The array itself
time = np.linspace(timemin,timemax)

# The equation created above will calculate all data points & create a graph off of it
x = odeint(cpu_time, R, time, args=(cyc,))

# The data will be processed here
print("Your Data Is Being Printed... \n")
print(x)

# This is the information needed to create the plot including the title & the data itself
plt.plot(time, x)
plt.title('CPU Time')
plt.xlabel('Time')
plt.ylabel('Instructions')
plt.show()